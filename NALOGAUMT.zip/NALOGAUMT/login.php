﻿<?php session_start(); $err = isset($_GET["err"]) ? $_GET["err"] : ""; ?>
<!DOCTYPE html>
<html lang="sl">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Prijava - eKonferenca</title>
<style>
body{margin:0;padding:0;font-family:Arial,Helvetica,sans-serif;background:linear-gradient(180deg,#1f9f83,#1b7f86 45%,#156a7a);}
.wrap{min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px}
.card{width:95%;max-width:520px;background:#fff;border-radius:12px;box-shadow:0 12px 32px rgba(0,0,0,.25);overflow:hidden}
.top{background:#1a8f9b;color:#eafffb;padding:16px 18px;text-align:center}
.body{padding:18px}
.row{display:flex;align-items:center;background:#1e5a66;border-radius:24px;padding:8px 12px;margin:10px 0}
.row input{flex:1;border:0;outline:0;background:transparent;color:#e7fbff;font-size:16px}
.btn{display:block;width:140px;margin:10px auto 0;border:0;background:#1f7ea0;color:#e9fffb;padding:10px 16px;border-radius:10px;font-weight:700;cursor:pointer}
.err{color:#b64848;text-align:center;font-size:13px;min-height:16px}
.link{text-align:center;margin-top:10px}
.link a{color:#0d3d4b}
</style>
</head>
<body>
<div class="wrap">
<div class="card">
<div class="top"><h2>Prijava v eKonferenco</h2></div>
<div class="body">
<form method="post" action="auth.php">
<div class="row">👤&nbsp;<input type="email" name="email" placeholder="Email" required></div>
<div class="row">🔒&nbsp;<input type="password" name="password" placeholder="Geslo" required></div>
<div class="err"><?php echo htmlspecialchars($err); ?></div>
<button type="submit" class="btn">Prijava</button>
</form>
<div class="link"><a href="start.html">Nazaj na začetno</a></div>
</div>
</div>
</div>
</body>
</html>